Redress downloader
----------------------------
Author: Vichingo455
License: GPL-2
----------------------------
This software uses code of
aria2 under the GPL v2
license. aria2 is a trademark of its project and its copyrighted by its authors
----------------------------
HOW TO USE:
1. Connect to the net
2. Open the "Download-App.cmd" file
3. Wait until the apk is downloaded
This contains a debug script if the script is not working, just run it and DM me on Discord sending the For_debugging.log file
Discord: Vichingo455#7638
----------------------------
Copyright (C) 2022 Vichingo455. All rights reserved.
